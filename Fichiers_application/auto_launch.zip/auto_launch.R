#¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤
# Objectif : lance l'application

# A.Jorant - Nov 2024

# R version 4.4.1

# encoding UTF8
#¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤



# la direction du script est donnée en argument dans l'appel
wd <- commandArgs(trailingOnly = TRUE)
print(wd)
wd <- paste(wd, collapse = ' ')

setwd(wd)

library(shiny)
runApp('Scripts/TBM_App.R', launch.browser = TRUE)









